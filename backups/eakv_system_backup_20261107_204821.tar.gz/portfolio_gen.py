#!/usr/bin/env python3
import os

def generate_portfolio():
    print("[PORTFOLIO-GEN] Compiling high-authority SEO landing page...")
    html_content = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Elite AKV | C & Unix Systems Engineer</title>
    <meta name="description" content="Portfolio of EAKV - Low-level C programming, Unix systems architecture, zero-bloat infrastructure engineering, and automated build-in-public pipelines.">
    <meta name="keywords" content="C Systems Engineer, Unix Programming, Low-Level Infrastructure, EAKV, Software Architecture">
    <meta name="author" content="EAKV">
    
    <!-- Open Graph / Google Search Metadata -->
    <meta property="og:title" content="Elite AKV | C & Unix Systems Engineer">
    <meta property="og:description" content="Low-level C systems architecture, zero-bloat execution, and automated engineering pipelines.">
    <meta property="og:type" content="website">
    
    <style>
        body {
            background-color: #0d1117;
            color: #c9d1d9;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 40px 20px;
            line-height: 1.6;
        }
        header {
            border-bottom: 1px solid #30363d;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        h1 {
            color: #58a6ff;
            font-size: 2.2rem;
            margin: 0 0 10px 0;
        }
        .tagline {
            color: #8b949e;
            font-size: 1.1rem;
            font-family: monospace;
        }
        .section {
            background: #161b22;
            border: 1px solid #30363d;
            border-radius: 8px;
            padding: 24px;
            margin-bottom: 24px;
        }
        h2 {
            color: #f0883e;
            font-size: 1.4rem;
            margin-top: 0;
        }
        ul {
            padding-left: 20px;
        }
        li {
            margin-bottom: 8px;
        }
        .links a {
            color: #58a6ff;
            text-decoration: none;
            margin-right: 20px;
            font-weight: bold;
            font-family: monospace;
        }
        .links a:hover {
            text-decoration: underline;
        }
        footer {
            text-align: center;
            color: #8b949e;
            font-size: 0.9rem;
            margin-top: 40px;
            border-top: 1px solid #30363d;
            padding-top: 20px;
        }
    </style>
</head>
<body>
    <header>
        <h1>Elite AKV</h1>
        <div class="tagline">⚡ C & Unix Systems Engineer | Low-Level Infrastructure Architecture</div>
    </header>

    <div class="section">
        <h2>About Me</h2>
        <p>Rigorous systems engineer specializing in <strong>low-level C programming, memory management, POSIX threading, and zero-bloat execution</strong>. Built and deployed sovereign automation pipelines under WSL, combining strict performance standards with disciplined build-in-public engineering.</p>
    </div>

    <div class="section">
        <h2>Core Competencies & Stack</h2>
        <ul>
            <li><strong>Languages:</strong> C, Python, Bash / POSIX Shell</li>
            <li><strong>Systems Architecture:</strong> Unix process control, signal handling, memory safety, concurrency primitives</li>
            <li><strong>Tooling & Pipeline:</strong> Custom WSL command centers, automated video rendering pipelines, Git watchdogs</li>
        </ul>
    </div>

    <div class="section links">
        <h2>Connect & Proof of Work</h2>
        <a href="https://github.com" target="_blank">GitHub</a>
        <a href="https://lnkd.in/p/emWgZFpG" target="_blank">LinkedIn</a>
    </div>

    <footer>
        <p>Maintained by the EAKV Sovereign Engine. Zero Bloat. Pure Execution.</p>
    </footer>
</body>
</html>
"""
    with open("index.html", "w") as f:
        f.write(html_content)
    print("[SUCCESS] index.html compiled successfully. Ready for GitHub Pages deployment.")

if __name__ == "__main__":
    generate_portfolio()
